var searchData=
[
  ['hallar_5fproblema_229',['hallar_problema',['../class_curso.html#a242ec71cd39b94f0a16f96f468cd8894',1,'Curso']]]
];
