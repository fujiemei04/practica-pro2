var searchData=
[
  ['usuario_282',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario']]],
  ['usuario_5finscrito_283',['usuario_inscrito',['../class_cjt___usuarios.html#a3cebbc7bf1ed9088e0af21d4092a25bf',1,'Cjt_Usuarios']]]
];
