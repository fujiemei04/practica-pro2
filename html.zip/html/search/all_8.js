var searchData=
[
  ['nueva_5fsesion_113',['nueva_sesion',['../class_cjt___sesiones.html#adde256f018e6b091527a21f564b4f0c2',1,'Cjt_Sesiones']]],
  ['nuevo_5fcurso_114',['nuevo_curso',['../class_cjt___cursos.html#a603a7ad7f3223d14cda742eab11b792b',1,'Cjt_Cursos']]],
  ['nuevo_5fcurso_5faux_115',['nuevo_curso_aux',['../class_curso.html#aac0f2c55ad24dfcbce88999e2833121c',1,'Curso']]],
  ['nuevo_5fproblema_116',['nuevo_problema',['../class_cjt___problemas.html#a700c0d0cfb4638e1877e62b6a3b85873',1,'Cjt_Problemas']]],
  ['numero_5fproblemas_117',['numero_problemas',['../class_sesion.html#ac1d7a01973b833526f556d29922a47b2',1,'Sesion']]]
];
