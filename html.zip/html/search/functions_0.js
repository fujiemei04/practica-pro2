var searchData=
[
  ['act_5fproblemes_5fenviables_5faux_173',['act_problemes_enviables_aux',['../class_sesion.html#afabc0bd72f845b300042fb035e349be5',1,'Sesion']]],
  ['actualizar_5fproblemas_5fenv_174',['actualizar_problemas_env',['../class_cjt___sesiones.html#a05ffbe09adc5fb3a23db55eb3bab1047',1,'Cjt_Sesiones']]],
  ['alta_5fusuario_175',['alta_usuario',['../class_cjt___usuarios.html#aa6c2a7675409f6a76c56f2e8294e415d',1,'Cjt_Usuarios']]],
  ['anadir_5fenv_5fprob_5faux_176',['anadir_env_prob_aux',['../class_usuario.html#a3004618c2688cc406b6381bf9db5cbe5',1,'Usuario']]],
  ['anadir_5fenvios_5fa_5fprob_177',['anadir_envios_a_prob',['../class_cjt___usuarios.html#aa7796fc424a0ab803539c9d17083b5ac',1,'Cjt_Usuarios']]],
  ['anadir_5fpr_178',['anadir_pr',['../class_usuario.html#a21b6688314e5c19bbf42e9d124218563',1,'Usuario']]],
  ['anadir_5fprob_5fenv_179',['anadir_prob_env',['../class_usuario.html#ab1597a04cf3468132cdaef3380288126',1,'Usuario']]],
  ['anadir_5fprob_5fenviable_180',['anadir_prob_enviable',['../class_cjt___usuarios.html#a0619b7f6c99c7592707cddf9e299bbaa',1,'Cjt_Usuarios']]],
  ['anadir_5fprob_5fresuelto_181',['anadir_prob_resuelto',['../class_cjt___usuarios.html#ab0c34a6249ac1adcc015f1806003eaa2',1,'Cjt_Usuarios']]]
];
