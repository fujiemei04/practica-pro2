var searchData=
[
  ['baja_5fusuario_182',['baja_usuario',['../class_cjt___usuarios.html#a4d827a290aa0799286262fcaf309ebde',1,'Cjt_Usuarios']]],
  ['buscar_5fproblema_183',['buscar_problema',['../class_cjt___problemas.html#a5b3f45ca9974f34eb724f887b4b66d20',1,'Cjt_Problemas']]],
  ['buscar_5fsesion_5fprob_184',['buscar_sesion_prob',['../class_curso.html#a3d4bf7da2435859049de9431b5a67395',1,'Curso']]],
  ['buscar_5fusuario_185',['buscar_usuario',['../class_cjt___usuarios.html#ac9e7b231889d68dc9833afe593a4643b',1,'Cjt_Usuarios']]]
];
