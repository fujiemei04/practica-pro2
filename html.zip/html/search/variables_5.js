var searchData=
[
  ['resueltos_300',['resueltos',['../class_usuario.html#ae36f95f46ba7e3870efd346d8ab32856',1,'Usuario']]]
];
