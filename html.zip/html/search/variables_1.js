var searchData=
[
  ['envios_287',['envios',['../class_usuario.html#a485a741c0646e6414bd6cf669a77fc9c',1,'Usuario']]],
  ['envios_5fa_5fprob_288',['envios_a_prob',['../class_usuario.html#a59d40de3ab41bec3254dd76b7a3d6c5e',1,'Usuario']]],
  ['envios_5fcorrectos_289',['envios_correctos',['../class_problema.html#a086bcfe12a44df13cb5312471fbfa467',1,'Problema']]],
  ['envios_5fproblemas_290',['envios_problemas',['../class_usuario.html#ad6b197fe54aa793bd31bacb6afe21d73',1,'Usuario']]],
  ['envios_5ftotales_291',['envios_totales',['../class_problema.html#abaee308b1ebcc3c1b3620fffc33a4196',1,'Problema']]]
];
