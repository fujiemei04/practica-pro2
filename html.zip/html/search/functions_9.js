var searchData=
[
  ['prob_5fresolucio_272',['prob_resolucio',['../class_usuario.html#a93ef173a7809d66b252aed399702b124',1,'Usuario']]],
  ['prob_5fresolucions_273',['prob_resolucions',['../class_cjt___usuarios.html#a70d1048b23c023fab97f72068c83d0a6',1,'Cjt_Usuarios']]],
  ['problema_274',['Problema',['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema']]]
];
