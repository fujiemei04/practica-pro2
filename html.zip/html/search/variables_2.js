var searchData=
[
  ['inscritos_5factual_292',['inscritos_actual',['../class_curso.html#ae5cefc9275276b48ad9fb8b9d53a57f1',1,'Curso']]]
];
