var searchData=
[
  ['quitar_5fprob_5fenv_275',['quitar_prob_env',['../class_cjt___usuarios.html#a54a98c515f877e0b0cf86c9fea51cbb3',1,'Cjt_Usuarios']]],
  ['quitar_5fproblema_5fenv_276',['quitar_problema_env',['../class_usuario.html#af407a4dad184b6f40f137a626380a446',1,'Usuario']]]
];
