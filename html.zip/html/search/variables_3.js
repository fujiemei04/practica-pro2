var searchData=
[
  ['numero_5fproblemas_293',['numero_problemas',['../class_sesion.html#ac1d7a01973b833526f556d29922a47b2',1,'Sesion']]]
];
